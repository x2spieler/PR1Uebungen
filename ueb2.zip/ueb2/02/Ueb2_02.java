public class Ueb2_02 {
	public static void main(String[] args) {
		int x;
		double y;

		// x = 5.4 * 4.3;
		// funktionierend:
		x = (int) (5.4 * 4.3);
		// x = 3.00001 - 1.00001;
		// funktionierend:
		x = (int) (3.00001 - 1.00001);
		x = 4/5;
		y = 2 - 1;
		y = 3.0 * 2.6;
	}
}
