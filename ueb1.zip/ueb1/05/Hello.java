/**
 *	PR1, WS2015/16
 *
 *	Leonard Oertelt
 *	Matrikelnummer 1276156
 *	leonard.oertelt@stud.hs-hannover.de
 * 
 *	Fr 2. Okt 13:47:34 CEST 2015
 *	-----------------------------------------
 *	Dieses Programm gibt "Hello World" in der Konsole aus!
 */
public class Hello {
	/* Methode, die beim Programmstart zuerst ausgeführt wird. */
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}
