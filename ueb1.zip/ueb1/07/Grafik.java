/**
 *	PR1, WS2015/16
 *
 *	Leonard Oertelt
 *	Matrikelnummer 1276156
 *	leonard.oertelt@stud.hs-hannover.de
 * 
 *	Fr 2. Okt 13:49:16 CEST 2015
 *	-----------------------------------------
 *	Dieses Programm "schreibt" ein Bild als Augabe in der Konsole!
 */
public class Grafik {
	/* Methode, die beim Programmstart zuerst ausgeführt wird. */
	public class Grafik {
		public static void main(String[] args) {
			System.out.println("  _______");
			System.out.println(" /       \\");
			System.out.println("/         \\");
			System.out.println("-\"-\'-\"-\'-\"-");
			System.out.println("\\         /");
			System.out.println(" \\_______/");
		}
	}
